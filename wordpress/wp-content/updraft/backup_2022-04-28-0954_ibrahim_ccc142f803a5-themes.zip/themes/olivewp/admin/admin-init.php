<?php
if(is_admin()){
	require OLIVEWP_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}